import os

def DirectoryScanner(DirectoryName="Marvellous"):

    Ret = os.path.exists(DirectoryName)
    
    if(Ret==False):
        print("There is no such Directory :/")
        return
    
    Ret = os.path.isdir(DirectoryName)
    if Ret == False:
        print("Unable to scan as its not directory")
        return
    
    print("Context of the Directory are: ")

    for FolderName,SubFolderName,FileName in os.walk(DirectoryName):
        print("Folder Name: ",FolderName)

        for subf in SubFolderName:
            print("SubFolder Name: ",subf)

        for fname in FileName:
            print("File Name: ",fname)

def main():
    DirectoryName = input("Enter the Name of Directory: ")

    DirectoryScanner(DirectoryName)
    
if __name__=="__main__":
    main()